require 'open-uri'
require 'nokogiri'
require 'pry'
require 'json'

require "nbascores/version"
require "nbascores/cli"
require "nbascores/nbascrape"
require "nbascores/nba_stat"

module Nbascores
  # Your code goes here...
end
